let services = [];
let servicesLoaded = false;

const grid = document.querySelector("#service-grid");
const searchInput = document.querySelector("#search-input");
const categorySelect = document.querySelector("#category-select");
const resultCount = document.querySelector("#results-count");
const emptyState = document.querySelector("#empty-state");
const directoryStatus = document.querySelector("#directory-status");
const chips = [...document.querySelectorAll(".chip")];
let activeCategory = "all";

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function cardTemplate(service) {
  const query = encodeURIComponent(service.address);
  const phone = service.phone.replace(/[^+\d]/g, "");
  return `<article class="service-card">
    <div class="card-top"><span class="category-label">${escapeHtml(service.category)}</span><span class="card-icon" aria-hidden="true">${escapeHtml(service.icon)}</span></div>
    <h3>${escapeHtml(service.name)}</h3><p class="description">${escapeHtml(service.description)}</p>
    <p class="card-detail"><span aria-hidden="true">◎</span><span>${escapeHtml(service.address)}</span></p>
    <p class="card-detail"><span aria-hidden="true">◷</span><span>${escapeHtml(service.hours)}</span></p>
    <p class="card-detail"><span aria-hidden="true">☎</span><a class="phone-link" href="tel:${phone}">${escapeHtml(service.phone)}</a></p>
    <div class="card-footer"><span class="verified">${escapeHtml(service.verified)}</span><a class="card-link" href="https://www.google.com/maps/search/?api=1&query=${query}" target="_blank" rel="noreferrer">Directions ↗</a></div>
  </article>`;
}

function renderServices() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = services.filter(service => {
    const matchesCategory = activeCategory === "all" || service.category === activeCategory;
    const haystack = `${service.name} ${service.category} ${service.description} ${service.address} ${service.hours} ${service.search}`.toLowerCase();
    return matchesCategory && haystack.includes(query);
  });
  grid.innerHTML = filtered.map(cardTemplate).join("");
  grid.hidden = filtered.length === 0;
  emptyState.hidden = !servicesLoaded || filtered.length > 0;
  document.querySelector('[data-category="all"] span').textContent = servicesLoaded ? services.length : "";
  resultCount.textContent = `${filtered.length} ${filtered.length === 1 ? "service" : "services"}`;
}

async function loadServices() {
  try {
    const response = await fetch("/api/services");
    if (!response.ok) {
      throw new Error(`Service request failed (${response.status}).`);
    }
    const data = await response.json();
    if (!Array.isArray(data.services)) {
      throw new Error("The service response was invalid.");
    }
    services = data.services;
    servicesLoaded = true;
    directoryStatus.hidden = true;
    renderServices();
  } catch (error) {
    console.error("Could not load community services:", error);
    directoryStatus.textContent = "We couldn't load services. Please start the backend and refresh the page.";
    directoryStatus.hidden = false;
    grid.hidden = true;
    emptyState.hidden = true;
    resultCount.textContent = "";
  }
}

function setCategory(category) {
  activeCategory = category;
  categorySelect.value = category;
  chips.forEach(chip => {
    const selected = chip.dataset.category === category;
    chip.classList.toggle("active", selected);
    chip.setAttribute("aria-pressed", String(selected));
  });
  renderServices();
}

searchInput.addEventListener("input", renderServices);
categorySelect.addEventListener("change", () => setCategory(categorySelect.value));
chips.forEach(chip => chip.addEventListener("click", () => setCategory(chip.dataset.category)));
document.querySelector("#reset-search").addEventListener("click", () => {
  searchInput.value = "";
  setCategory("all");
  searchInput.focus();
});

document.querySelector("#correction-form").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const submitButton = form.querySelector('button[type="submit"]');
  const status = document.querySelector("#form-status");
  const suggestion = Object.fromEntries(new FormData(form).entries());
  submitButton.disabled = true;
  status.textContent = "Sending your suggestion…";

  try {
    const response = await fetch("/api/suggestions", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(suggestion)
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "Could not send your suggestion.");
    }
    form.reset();
    status.textContent = "Suggestion received. Thanks for helping your community!";
  } catch (error) {
    console.error("Could not send suggestion:", error);
    status.textContent = `${error.message} Please try again.`;
  } finally {
    submitButton.disabled = false;
  }
});

loadServices();
