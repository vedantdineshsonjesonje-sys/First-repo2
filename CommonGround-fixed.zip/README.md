# CommonGround — local service directory

A responsive community-service directory with keyword search, category filters, listing cards with directions, and a correction suggestion form. The Python backend serves the site, provides the service API, and stores suggestions in SQLite.

## Run it locally

Requires Python 3. Run `python backend.py` from this folder, then visit `http://127.0.0.1:8000`. The backend creates `commonground.sqlite3` on first start and seeds it with the example listings. Suggestions submitted through the form are saved to the same database.

The site now uses the backend API, so opening `index.html` directly or serving the folder with a static-only server will not load listings or submit suggestions.

## Publish with GitHub Pages

GitHub Pages can host the front-end files, but it cannot run this Python backend. A production deployment needs a Python-capable host for `backend.py` and a configured API URL/proxy before the site can load services or accept suggestions. `.nojekyll` is included for static hosting.

## Demo data and form behavior

The Springfield services and phone numbers are fictional examples. Do not use them to seek real assistance. Replace them with verified listings before sharing the site. Suggestions are stored locally in the backend's SQLite database; they are not sent to an organization or administrator.

## Next steps for a production directory

1. Choose the launch area and collect consented, verified service data.
2. Replace the seeded listings in `backend.py` with verified service data and add a review workflow for new suggestions.
3. Add an administrator login, spam protections, and a contact path for data corrections.
4. Verify service details regularly and show the date each listing was checked.

## Firebase Hosting

Run `python build_static.py` before deploying Firebase Hosting. The configuration publishes only the generated `public/` folder, excluding backend code and SQLite data. Firebase Hosting alone cannot run `backend.py`; configure a deployed Python service and a same-origin `/api/**` reverse proxy before using this frontend on Firebase. No backend host or Firebase service has been provisioned by this repository.

For a working local full-stack demo, use `python backend.py`. For hosting, run the Python application behind an HTTPS reverse proxy with persistent SQLite storage; adapt the bind address and port to the host. GitHub upload alone does not deploy the backend.

## Checks

Run `python -B -m unittest test_backend.py` and `node --check app.js`. Static downloads are restricted to the frontend assets for both GET and HEAD. Local databases must not be committed or published.
